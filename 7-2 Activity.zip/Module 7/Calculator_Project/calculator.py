#Simple Calculator-Module Seven Activity

#Function: add
#Purpose: Return sum of two numbers

def add(num1, num2):
    return num1 + num2

#Function: subtract
#Purpose: Return the difference of two numbers

def subtract(num1, num2):
    return num1 - num2

#Function: multiply
#Purpose: Return product of two numbers

def multiply(num1, num2):
    return num1 * num2

#Function: divide
#Purpose: Divides two numbers and handles division by zero

def divide(num1, num2):
    if num2 == 0:
        return 'Error: Cannot divide by zero.'
    return num1 / num2

#Function: display_menu
#Purpose: Displays the calculator menu

def display_menu():
    print('\nSimple Calculator')
    print('1. Addition')
    print('2. Subtraction')
    print('3. Multiplication')
    print('4. Division')
    print('5. Exit')

#Function: main
#Purpose: Runs the calculator application

def main():
    while True:
        display_menu()
        choice = input('Select an operation (1-5): ')
        if choice == '5':
            print('Thank you for using the calculator.')
            break

        if choice not in ['1', '2', '3', '4', '5']:
            print('Invalid selection. Please try again.')
            continue

        number1 = float(input('Enter first number: '))
        number2 = float(input('Enter second number: '))

        if choice == '1':
            result = add(number1, number2)
        elif choice == '2':
            result = subtract(number1, number2)
        elif choice == '3':
            result = multiply(number1, number2)
        elif choice == '4':
            result = divide(number1, number2)
        print('Result:', result)

#Run program only when this file is executed directly
if __name__ == '__main__':
    main()