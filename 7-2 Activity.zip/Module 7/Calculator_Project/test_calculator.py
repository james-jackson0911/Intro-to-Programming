#Unit Tests for Calculator Functions

#Import calculator functions
from calculator import add
from calculator import subtract
from calculator import multiply
from calculator import divide

#Test: Addition
#Purpose: Verify addition returns correct result
def test_add():
    assert add(5,3) == 8

#Test: Subtraction
#Purpose: Verify subtraction returns correct result
def test_subtract():
    assert subtract(10, 4) == 6

#Test: Multiplication
#Purpose: Verigy multiplication returns correct result
def test_multiply():
    assert multiply(6, 7) == 42

#Test: Division
#Purpose: Verify division returns correct result
def test_divide():
    assert divide(20, 5) == 4

#Test: Division by Zero
#Purpose: Verify divide() handles edge case
def test_divide_by_zero():
    assert divide(10, 0) == 'Error: Cannot divide by zero.'
