# Personal Budgeting Application

## Overview

The Personal Budgeting Application is a command-line Python program designed to help users manage their personal finances. The application allows users to enter income, track expenses by category, set savings goals, monitor spending habits, and visualize expense data.

This project was developed as part of CS 500 and demonstrates object-oriented programming principles, modular code design, input validation, file persistence, data visualization, and secure coding practices.

---

## Features

### Income Management
- Set and update monthly income
- Store income information for budgeting calculations

### Expense Tracking
- Track expenses by category
- Record:
  - Category
  - Amount
  - Description
  - Date
- Calculate total expenses

### Savings Goals
- Set a savings goal
- Monitor progress toward the goal
- Receive feedback on whether savings goals are being met

### Data Persistence
- Save budget information to a JSON file
- Automatically load saved data when the application starts

### Data Visualization
- Generate a chart displaying expenses by category
- Uses Matplotlib for visualization

### Input Validation
- Prevent negative values
- Validate numeric input
- Validate dates using YYYY-MM-DD format
- Handle invalid user entries gracefully

---

## Technologies Used

- Python 3
- JSON
- Matplotlib
- Visual Studio Code (VS Code)

---

## Project Structure

```text
CS500_PersonalBudgetApplication/
│
├── budget_app.py
├── budget_data.json
├── flowchart.drawio
├── README.md
└── screenshots/
```

---

## Running the Application

### 1. Install Python

Verify Python is installed:

```bash
python --version
```

or

```bash
py --version
```

### 2. Install Required Package

```bash
py -m pip install matplotlib
```

### 3. Run the Program

```bash
python budget_app.py
```

or

```bash
py budget_app.py
```

---

## Menu Options

```text
1. Set Income
2. Set Savings Goal
3. Add Expense
4. View Total Expenses
5. View Savings Progress
6. Visualize Expenses
7. Save & Exit
```

---

## Example Workflow

1. Set monthly income
2. Set savings goal
3. Add expense entries
4. View total expenses
5. Check savings progress
6. Generate expense visualization
7. Save and exit

---

## Object-Oriented Design

### BudgetCategory Class

Responsible for:
- Storing expenses for a category
- Calculating category expense totals

### BudgetManager Class

Responsible for:
- Managing income
- Managing savings goals
- Managing expense categories
- Saving and loading data
- Generating visualizations

---

## Security and Validation

The application follows secure coding practices including:

- Input validation
- Numeric range checking
- Date validation
- Exception handling
- File handling with error management
- Prevention of invalid financial data entry

---

## Author

James Jackson

CS 500 Software Development Project
Southern New Hampshire University