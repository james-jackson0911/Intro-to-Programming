#Unit tests for the Personal Budget Application

#These test verify that the core functionality of the BudgetManager and BudgetCategory classes works as expected.
import unittest
from budget_app import BudgetManager, get_valid_float, get_valid_date
from budget_app import BudgetCategory

class TestBudgetManager(unittest.TestCase):
    #Tests for the BudgetManager class.
    def setUp(self):
        self.manager = BudgetManager()

    # Clear any data loaded from budget_data.json
        self.manager.categories = {}
        self.manager.income = 0
        self.manager.savings_goal = 0

    # Set fresh test values
        self.manager.set_income(5000)
        self.manager.set_savings_goal(1000)

    def test_set_income(self):
        #Verify that income is stored correctly.
        self.manager.set_income(6000)
        self.assertEqual(self.manager.income, 6000)

    def test_set_savings_goal(self):
        #Verify that savings goal is stored correctly.
        self.manager.set_savings_goal(1500)
        self.assertEqual(self.manager.savings_goal, 1500)

    def test_add_expense_and_total_expenses(self):
        #Verify that expenses are added correctly and total expenses are calculated accurately.
        self.manager.add_expense("Food", 200, "Groceries", "2024-06-01")
        self.manager.add_expense("Transport", 100, "Gas", "2024-06-02")
        total = self.manager.total_expenses()
        self.assertEqual(total, 300)

    def test_progress_toward_goal(self):
        #Verify that progress toward savings goal is calculated correctly.
        self.manager.add_expense("Food", 200, "Groceries", "2024-06-01")
        current_savings, remaining = self.manager.progress_toward_goal()
        self.assertEqual(current_savings, 4800)  # 5000 - 200
        self.assertEqual(remaining, -3800)  # 1000 - 4800

class TestBudgetCategory(unittest.TestCase):
    #Tests for the BudgetCategory class.
    def setUp(self):
        #Initialize a BudgetCategory instance for testing.
        self.category = BudgetCategory("Food")

    def test_add_expense_and_total_expenses(self):
        #Verify that expenses are added correctly and total expenses are calculated accurately.
        self.category.add_expense(50, "Lunch", "2024-06-01")
        self.category.add_expense(30, "Dinner", "2024-06-02")
        total = self.category.total_expenses()
        self.assertEqual(total, 80)

if __name__ == '__main__':
    unittest.main()