import json
import matplotlib.pyplot as plt
from datetime import datetime

# Budget Category Class
class BudgetCategory:

    def __init__(self, name):
        self.name = name
        self.expenses = []

    # TO DO: Define function add_expense()
    def add_expense(self, amount, description, date):
        expense = {
            'amount': amount,
            'description': description,
            'date': date
        }

        self.expenses.append(expense)

    # TO DO: Define function total_expenses()
    def total_expenses(self):
        return sum(expense['amount'] for expense in self.expenses)


# Budget Manager Class
class BudgetManager:

    def __init__(self):
        self.income = 0.0
        self.savings_goal = 0.0
        self.categories = {}
        self.load_data()


    # TO DO: Define function: set_income()
    def set_income(self, income):
        self.income = income

    # TO DO: Define function: set_savings_goal()
    def set_savings_goal(self, goal):
        self.savings_goal = goal


    # TO DO: Define function: add_expense()
    def add_expense(self, category_name, amount, description, date):
        if category_name not in self.categories:
            self.categories[category_name] = BudgetCategory(category_name)
        self.categories[category_name].add_expense(amount, description, date)

    # TO DO: Define function: total_expenses()
    def total_expenses(self):
        return sum(category.total_expenses() for category in self.categories.values())

    # TO DO: Define function: progress_toward_goal()
    def progress_toward_goal(self):
        total_expenses = self.total_expenses()
        current_savings = self.income - total_expenses
        return current_savings, self.savings_goal - current_savings

    # TO DO: Define function: save_data()
    def save_data(self):
        data = {
            'income': self.income,
            'savings_goal': self.savings_goal,
            'categories': {name: category.expenses for name, category in self.categories.items()}
        }
        with open('budget_data.json', 'w') as f:
            json.dump(data, f)

    # TO DO: Define function: load_data()
    def load_data(self):
        try:
            with open('budget_data.json', 'r') as f:
                data = json.load(f)
                self.income = data.get('income', 0.0)
                self.savings_goal = data.get('savings_goal', 0.0)
                for name, expenses in data.get('categories', {}).items():
                    category = BudgetCategory(name)
                    category.expenses = expenses
                    self.categories[name] = category
        except FileNotFoundError:
            pass

    # TO DO: Define function: visualize_expenses()
    def visualize_expenses(self):
        category_names = list(self.categories.keys())
        total_expenses = [category.total_expenses() for category in self.categories.values()]

        plt.figure(figsize=(10, 6))
        plt.bar(category_names, total_expenses, color='skyblue')
        plt.xlabel('Categories')
        plt.ylabel('Total Expenses')
        plt.title('Expenses by Category')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()


# Input Validation Functions
   
# TO DO: Define function: get_valid_float()
def get_valid_float(prompt):
    while True:
            try:
                value = float(input(prompt))
                if value < 0:
                    print("Please enter a non-negative number.")
                else:
                    return value
            except ValueError:
                print("Invalid input. Please enter a valid number.")
 
# TO DO: Define function: get_valid_date() 
def get_valid_date(prompt):
        while True:
            date_str = input(prompt)
            try:
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
                return date_obj.strftime("%Y-%m-%d")
            except ValueError:
                print("Invalid date format. Please enter a date in the format YYYY-MM-DD.")


# Main Program
def main():
    manager = BudgetManager()
    
    print("Welcome to Personal Budgeting Application!")
    
    while True:
        print("\nMenu:")
        print("1. Set Income")
        print("2. Set Savings Goal")
        print("3. Add Expense")
        print("4. View Total Expenses")
        print("5. View Savings Progress")
        print("6. Visualize Expenses")
        print("7. Save & Exit")
        
        choice = input("Choose an option (1-7): ")

        if choice == '1':
        	# TO DO: Prompt for monthly income as input. Set income and display what income is set to.
            income = get_valid_float("Enter your monthly income: $")
            manager.set_income(income)
            print(f"Income is set to: ${income:.2f}")
        
        elif choice == '2':
        	# TO DO: Prompt for savings goal as input. Set savings goal and display savings goal is set to.
            goal = get_valid_float("Enter your savings goal: $")
            manager.set_savings_goal(goal)
            print(f"Savings goal is set to: ${goal:.2f}")  

        elif choice == '3':
        	# TO DO: 
            #      Prompt for expense category as input. 
            #      Prompt for expense amount as input. 
            #      Prompt for a brief description of the expense. 
            #      Prompt for expense date in the format of (YYYY-MM-DD)
            #      Add expense.
            #      Display added expense.
             category_name = input("Enter expense category: ")
             amount = get_valid_float("Enter expense amount: $")
             description = input("Enter a brief description of the expense: ")
             date = get_valid_date("Enter expense date (YYYY-MM-DD): ")
             manager.add_expense(category_name, amount, description, date)
             print(f"Added expense: ${amount:.2f} for {description} on {date} in category '{category_name}'.")
        elif choice == '4':
	        # TO DO: Get total expenses. Display total expenses.
            total_expenses = manager.total_expenses()
            print(f"Total expenses: ${total_expenses:.2f}")
        
        elif choice == '5':
            # TO DO: Get progress towards goal. If on track, display: You are on track!, and also display the 
            #        current savings amount. If not on track, display: Current savings $xxx. You need $xxx to 
            #        reach your goal.
            current_savings, amount_needed = manager.progress_toward_goal()
            if current_savings >= manager.savings_goal:
                print(f"You are on track! Current savings: ${current_savings:.2f}")
            else:
                print(f"Current savings: ${current_savings:.2f}. You need ${amount_needed:.2f} to reach your goal.")

        elif choice == '6':
	        # TO DO: call visualize_expenses() to show expense graph or pie chart
            manager.visualize_expenses()
        
        elif choice == '7':
	        # TO DO: Save data and exit program. Display a message to indicate that data has been saved 
            #        successfully and exiting the program.
            manager.save_data()
            print("Data saved successfully. Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

